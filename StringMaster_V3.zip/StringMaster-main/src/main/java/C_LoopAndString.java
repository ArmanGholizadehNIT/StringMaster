public class C_LoopAndString {

    public static boolean containsDoubleChar(String s, char ch) {
        char[] arr=s.toCharArray();
        for(int i=0;i<s.length()-1;i++){
            if(arr[i] == ch){
                if(arr[i]==arr[i+1]){
                    return true;
                }
            }
        }
        return false;
    }


    public static String caesarEncrypt(String s, int offset) {

        if( offset<0)
            offset=26+offset;

        if ( offset >26)
            offset = offset -26;

        char character;          //barai iterate kardan roi string

        String encrypted = "";   //barai save kardan jomle encrypt shode

        for(int i=0;i<s.length();i++){

            character = s.charAt(i);

            if(character >= 'a' && character <= 'z'){    //check if character a-z
                character =(char)(character + offset);
                if( character > 'z'){
                    character=(char)(character +'a' - 'z' -1);      //if the character goes out of bound
                }
                encrypted += character;
            }
            else if( character >= 'A' && character <= 'Z'){   //check if character A-Z
                character=(char)(character +offset);
                if ( character > 'Z'){
                    character=(char)(character + 'A' -'Z' -1);   //if the character goes out of bound
                }
                encrypted += character;
            }
            else{                                              // if the character is not an alphabet
                encrypted +=  character;
            }
        }
        return encrypted;
    }


    public static String caesarDecrypt(String s, int c) {

        if( c<0)
            c=26+c;

        if ( c >26)
            c = c -26;

        char character;             //barai iterate kardan bein string

        String decrypted= "";        //barai save kardan jomle decrypt shode

        for(int i = 0;i < s.length();i++){


            character = s.charAt(i);

            if(character >= 'a' && character <= 'z'){             //agar character bein a-z
                character=(char)(character-c);
                if(character <'a'){
                    character=(char)(character +'z'-'a'+1);       // if out of bound
                }
                decrypted += character;
            }
            else if(character >= 'A' && character <= 'Z'){        //agar character bein A-Z
                character = (char)(character-c);
                if(character < 'A'){                              // if out of bound
                    character = (char)(character +'Z'-'A'+1);
                }
                decrypted += character;
            }
            else{                                               // if the character is not an alphabet
                decrypted += character;
            }
            
        }
        return decrypted;
    }

    /*
    If you have implemented all the previous parts completely and correctly
    feel free and add other methods as much as you want. Each extra method
    can add up to 5 points.

    Each method must come with its own unit-test.
     */



    //method saade barai replace kardan e ye character ba character mored nazar
    public static String replacer (String s,char toBeReplaced,char ch  ){
        String text="";
        char holder;
        for(int i=0;i<s.length();i++){
            holder=s.charAt(i);
            if(holder == toBeReplaced){
                text += ch;

            }
            else{
                text +=holder;
            }

        }

        return text;
    }
}
