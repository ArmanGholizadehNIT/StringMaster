public class B_StringMethods {
    /**
     * <p>Makes the full name with specified the first and the last name. If a
     * field is not provided only use the provided one. If neither of fields
     * provided return an empty string.</p>
     *
     * @param firstName the given first name
     * @param lastName the given last name
     * @return the full name
     */
    public static String fullName(String firstName, String lastName) {
        if(firstName.isEmpty() && lastName.isEmpty())
            return "";
        else if(firstName.isEmpty())
            return lastName;
        else if(lastName.isEmpty())
            return firstName;
        else
            return firstName +" "+ lastName;
    }


    public static boolean certainNumberOfChar(String text, char ch, int cnt) {
        int count=0;
        char[] arr=text.toCharArray();
        for(int i=0;i<text.length();i++) {
            if (arr[i] == ch)
                count++;
        }

        return (cnt == count);
    }


    public static String firstWord(String wordA, String wordB) {
        int comp= wordA.compareTo(wordB);
        if(comp>0)
            return wordB;
        else
            return wordA;
    }
}
